function [SP,GD,IGD,pareto]=r2_MOGA(Testproblem)
%% Problem definition 
format long
disp(['The MOPs of Testproblem are : ', num2str(Testproblem)])

switch Testproblem
    case 'Furnace'
        CostFunction = @(x)Furnace(x);
        nVar=3;
        objDim = 2;
        VarMin=[669.4898 3.0734 -0.1] ;
        VarMax=[969.4898 10.0734 0];
        
%%%%%%%%%%%%%%%---ZDT Test Suite---%%%%%%%%%%%%%%%%%%               
    case 'ZDT1'
        CostFunction = @(x)MyCost1(x);
        nVar=30;
        objDim=2;
        VarMin=zeros(1,nVar);
        VarMax=ones(1,nVar);
        bounds=[2 2];
        load 'PFture_data\ZDT1PFt.mat';
    case 'ZDT2'
        CostFunction = @(x)MyCost2(x);
        nVar=30;
        objDim=2;
        VarMin=zeros(1,nVar);
        VarMax=ones(1,nVar);
        bounds=[2 2];
        load 'PFture_data\ZDT2PFt.mat';
    case 'ZDT3'
        CostFunction = @(x)MyCost3(x);
        nVar=30;
        objDim=2;
        VarMin=zeros(1,nVar);
        VarMax=ones(1,nVar);
        bounds=[2 2];
        load 'PFture_data\ZDT3PFt.mat';
    case 'ZDT4'
        CostFunction = @(x)MyCost4(x); 
        nVar=10;
        objDim=2;
        VarMin=[0 -5 -5 -5 -5 -5 -5 -5 -5 -5] ;
        VarMax=[1 5 5 5 5 5 5 5 5 5];
        bounds=[10 10];
        load 'PFture_data\ZDT4PFt.mat';
    case 'ZDT6'
        CostFunction = @(x)MyCost6(x);
        nVar=10;
        objDim=2;
        VarMin=zeros(1,nVar);
        VarMax=ones(1,nVar);
        bounds=[10 10];
        load 'PFture_data\ZDT6PFt.mat';
%%%%%%%%%%%%%%%---DTLZ Test Suite---%%%%%%%%%%%%%%%%%%
    case 'DTLZ1'
        CostFunction = @(x)MyCost11(x);
        nVar=7;
        objDim=3;
        VarMin=zeros(1,nVar);
        VarMax=ones(1,nVar);
        bounds=[1 1 1];
        load 'PFture_data\DTLZ1PFt.mat';
    case 'DTLZ2'
        CostFunction = @(x)MyCost12(x);
        nVar=12;
        objDim=3;
        VarMin=zeros(1,nVar);
        VarMax=ones(1,nVar);
        bounds=[2 2 2];
        load 'PFture_data\DTLZ2PFt.mat';
    case 'DTLZ3'
        CostFunction = @(x)MyCost13(x);
        nVar=12;
        objDim=3;
        VarMin=zeros(1,nVar);
        VarMax=ones(1,nVar);
        bounds=[7  7  7];
        load 'PFture_data\DTLZ3PFt.mat';
    case 'DTLZ4'
        CostFunction = @(x)MyCost14(x);
        nVar=12;
        objDim=3;
        VarMin=zeros(1,nVar);
        VarMax=ones(1,nVar);
        bounds=[10  10  10];
        load 'PFture_data\DTLZ4PFt.mat';
    case 'DTLZ5'
        CostFunction = @(x)MyCost15(x);
        nVar=12;
        objDim=3;
        VarMin=zeros(1,nVar);
        VarMax=ones(1,nVar);
        bounds=[4  4  4];
        load 'PFture_data\DTLZ5PFt.mat';
    case 'DTLZ6'
        CostFunction = @(x)MyCost16(x);
        nVar=12;
        objDim=3;
        VarMin=zeros(1,nVar);
        VarMax=ones(1,nVar);
        bounds=[11 11 11];
        load 'PFture_data\DTLZ6PFt.mat';
    case 'DTLZ7'
        CostFunction = @(x)MyCost17(x);
        nVar=22;
        objDim=3;
        VarMin=zeros(1,nVar);
        VarMax=ones(1,nVar);
        bounds=[21 21 21];
        load 'PFture_data\DTLZ7PFt.mat';
%%%%%%%%%%%%%%%---UF Test Suite---%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    case 'UF1'
        CostFunction=@(x)MyCost21(x);     % UF1 benchmark function
        nVar=10;
        objDim=2;
        VarMin=[zeros(1,1) -ones(1,nVar-1)];
        VarMax=ones(1,nVar);
        load 'PFture_data\UF1PFt.mat';
    case 'UF2'
        CostFunction=@(x)MyCost22(x);    % UF2 benchmark function
        nVar=10;
        objDim=2;
        VarMin=[zeros(1,1) -ones(1,nVar-1)];
        VarMax=ones(1,nVar);
        load 'PFture_data\UF2PFt.mat';
    case 'UF3'
        CostFunction=@(x)MyCost23(x);   % UF3 benchmark function
        nVar=10;
        objDim=2;
        VarMin=zeros(1,nVar);
        VarMax=ones(1,nVar);
        load 'PFture_data\UF3PFt.mat';
    case 'UF4'
        CostFunction=@(x)MyCost24(x);  % UF4 benchmark function
        nVar=10;
        objDim=2;
        VarMin=[zeros(1,1) -2*ones(1,nVar-1)];
        VarMax=2*ones(1,nVar);
        load 'PFture_data\UF4PFt.mat';
    case 'UF5'
        CostFunction=@(x)MyCost25(x);   % UF5 benchmark function
        nVar=10;
        objDim=2;
        VarMin=[zeros(1,1) -ones(1,nVar-1)];
        VarMax=ones(1,nVar);
        load 'PFture_data\UF5PFt.mat';
    case 'UF6'
        CostFunction=@(x)MyCost26(x);  % UF6 benchmark function
        nVar=10;
        objDim=2;
        VarMin=[zeros(1,1) -ones(1,nVar-1)];
        VarMax=ones(1,nVar);
        load 'PFture_data\UF6PFt.mat';
    case 'UF7'
        CostFunction=@(x)MyCost27(x);  % UF7 benchmark function
        nVar=10;
        objDim=2;
        VarMin=[zeros(1,1) -ones(1,nVar-1)];
        VarMax=ones(1,nVar);
        load 'PFture_data\UF7PFt.mat';
%%%%%%%%%%% UF Test Suite  (Three objective optimization)  %%%%%%%%%%%%%%%%
    case 'UF8'
        CostFunction=@(x)MyCost28(x);   % UF8 benchmark function
        nVar=10;
        objDim=3;
        VarMin=[zeros(1,2) -2*ones(1,nVar-2)];
        VarMax=[ones(1,2) 2*ones(1,nVar-2)];
        load 'PFture_data\UF8PFt.mat';
    case 'UF9'
        CostFunction=@(x)MyCost29(x);   % UF9 benchmark function
        nVar=10;
        objDim=3;
        VarMin=[zeros(1,2) -2*ones(1,nVar-2)];
        VarMax=[ones(1,2) 2*ones(1,nVar-2)];
        load 'PFture_data\UF9PFt.mat';
    case 'UF10'
        CostFunction=@(x)MyCost30(x);  % UF10 benchmark function
        nVar=10;
        objDim=3;
        VarMin=[zeros(1,2) -2*ones(1,nVar-2)];
        VarMax=[ones(1,2) 2*ones(1,nVar-2)];
        load 'PFture_data\UF10PFt.mat';  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  WFG  benchmark function optimization
    case 'WFG1'
        CostFunction=@(x)MyCost31(x);  % WFG1 benchmark function
        nVar=24;
        objDim=5;
        VarMin=zeros(1,nVar);
        VarMax=2*(1:nVar);
        load 'PFture_data\WFG1_5.mat';  
    case 'WFG2'
        CostFunction=@(x)MyCost32(x);  % WFG2 benchmark function
        nVar=24;
        objDim=5;
        VarMin=zeros(1,nVar);
        VarMax=2*(1:nVar);
        load 'PFture_data\WFG2_5.mat';  
%     case 'WFG3'
%         CostFunction=@(x)MyCost33(x);  % WFG3 benchmark function
%         nVar=24;
%         objDim=5;
%         VarMin=zeros(1,nVar);
%         VarMax=2*(1:nVar);
%         load 'PFture_data\WFG3_5DPFt.mat';  
    case 'WFG4'
        CostFunction=@(x)MyCost34(x);  % WFG4 benchmark function
        nVar=24;
        objDim=5;
        VarMin=zeros(1,nVar);
        VarMax=2*(1:nVar);
        load 'PFture_data\WFG4_5.mat';  
    case 'WFG5'
        CostFunction=@(x)MyCost35(x);  % WFG5 benchmark function
        nVar=24;
        objDim=5;
        VarMin=zeros(1,nVar);
        VarMax=2*(1:nVar);
        bounds=[3 5 7];
        load 'PFture_data\WFG5_5.mat';  
    case 'WFG6'
        CostFunction=@(x)MyCost36(x);  % WFG6 benchmark function
        nVar=24;
        objDim=5;
        VarMin=zeros(1,nVar);
        VarMax=2*(1:nVar);
        load 'PFture_data\WFG6_5.mat';  
    case 'WFG7'
        CostFunction=@(x)MyCost37(x);  % WFG7 benchmark function
        nVar=24;
        objDim=5;
        VarMin=zeros(1,nVar);
        VarMax=2*(1:nVar);
        load 'PFture_data\WFG7_5.mat';  
    case 'WFG8'
        CostFunction=@(x)MyCost38(x);  % WFG8 benchmark function
        nVar=24;
        objDim=5;
        VarMin=zeros(1,nVar);
        VarMax=2*(1:nVar);
        load 'PFture_data\WFG8_5.mat';  
    case 'WFG9'
        CostFunction=@(x)MyCost39(x);  % WFG9 benchmark function
        nVar=24;
        objDim=5;
        VarMin=zeros(1,nVar);
        VarMax=2*(1:nVar);
        load 'PFture_data\WFG9_5.mat';  

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  problems %%%%%%%%%%%
    case '41'
        CostFunction=@ (x)MyCost41(x);
        nVar=14;
        objDim=5;
        VarMin=zeros(1,nVar);
        VarMax=ones(1,nVar);
     load 'PFture_data\DTLZ1_5_210.mat';
    case '42'
        CostFunction=@ (x)MyCost42(x);
        nVar=17;
        objDim=8;
        VarMin=zeros(1,nVar);
        VarMax=ones(1,nVar);
load 'PFture_data\DTLZ1_8_156.mat';
    case '43'
        CostFunction=@ (x)MyCost43(x);
        nVar=19;
        objDim=10;
        VarMin=zeros(1,nVar);
        VarMax=ones(1,nVar);
       load 'PFture_data\DTLZ2_10_275.mat';    
    case 44
        CostFunction=@ (x)MyCost44(x);
        nVar=24;
        objDim=15;
        VarMin=zeros(1,nVar);
        VarMax=ones(1,nVar);
%       load 'C:\Users\user\Desktop\nsga2tcyb\PFture_data\DTLZ2PFt.mat';
 case '51'
        CostFunction=@ (x)MyCost51(x);
        nVar=9;
        objDim=5;
        VarMin=zeros(1,nVar);
        VarMax=ones(1,nVar);
     load 'PFture_data\DTLZ1_5_210.mat';
    case '52'
        CostFunction=@ (x)MyCost42(x);
        nVar=12;
        objDim=8;
        VarMin=zeros(1,nVar);
        VarMax=ones(1,nVar);
load 'PFture_data\DTLZ1_8_156.mat';
    case '53'
        CostFunction=@ (x)MyCost43(x);
        nVar=14;
        objDim=10;
        VarMin=zeros(1,nVar);
        VarMax=ones(1,nVar);
       load 'PFture_data\DTLZ2_10_275.mat';  
       case '61'
        CostFunction=@ (x)MyCost51(x);
        nVar=14;
        objDim=5;
        VarMin=zeros(1,nVar);
        VarMax=ones(1,nVar);
     load 'PFture_data\DTLZ3_5_210.mat';
    case '62'
        CostFunction=@ (x)MyCost42(x);
        nVar=17;
        objDim=8;
        VarMin=zeros(1,nVar);
        VarMax=ones(1,nVar);
    load 'PFture_data\DTLZ3_8_156.mat';
    case '63'
        CostFunction=@ (x)MyCost43(x);
        nVar=19;
        objDim=10;
        VarMin=zeros(1,nVar);
        VarMax=ones(1,nVar);
       load 'PFture_data\DTLZ3_10_275.mat';  
    case '71'
        CostFunction=@ (x)MyCost51(x);
        nVar=14;
        objDim=5;
        VarMin=zeros(1,nVar);
        VarMax=ones(1,nVar);
     load 'PFture_data\DTLZ4_5_210.mat';
    case '72'
        CostFunction=@ (x)MyCost42(x);
        nVar=17;
        objDim=8;
        VarMin=zeros(1,nVar);
        VarMax=ones(1,nVar);
    load 'PFture_data\DTLZ4_8_156.mat';
    case '73'
        CostFunction=@ (x)MyCost43(x);
        nVar=19;
        objDim=10;
        VarMin=zeros(1,nVar);
        VarMax=ones(1,nVar);
       load 'PFture_data\DTLZ4_10_275.mat';  
end
%%%%%%% NSGA-II first using in the ZDT4 problem in this.  we must modifying
%%%%%%% the crossover and the the mutation operator
VarRange=[VarMin;VarMax];

VarSize=[1,nVar];
nobj=numel(CostFunction(zeros(1,nVar)));    % number of objective functions

%% Parameter setting
if objDim==2
    nPop=100;
    H=99;
else
    if objDim==3
    nPop=300;
    H=23;
    else 
        nPop=220;
    end
end
MaxIt=1000;                   % generation size

pCrossover=0.9;              % crossover possibility
pMutation=1/nVar;    % mutate ratio 

%% Initializing the population and the direction of dMOPSO-DE or R2-MOPSO
% Initializing the direction vector and the reference point
%%%%%%r2_MOEA uses the createVectors to generate weight vectors%%%%%%
% load 'c220-10.mat';
%  %Direction=wts;
% Direction=weights;
%%%% vspace is another weight generation not the direction vector, the improved r2_MOEA uses the createVectors to generate weight vectors%%%%%%%  
 %Direction=vspace(nPop,objDim);
 Direction=vector(nPop,objDim);
  Direction=(ones(nPop,objDim)./(Direction+1e-5))./(repmat((sum(ones(nPop,objDim)./(Direction+1e-5),2)),1,objDim));
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Direction=Direction';

%% Initialize the population

empty_individual.Position=[];
empty_individual.Cost=[];
empty_individual.Rank=[];
empty_individual.Sort=[];
pop=repmat(empty_individual,nPop,1);
childpop=repmat(empty_individual,nPop,1);
Mergepop=repmat(empty_individual,2*nPop,1);
idealp=inf*ones(objDim,1);
for i=1:nPop
    pop(i).Position=unifrnd(VarMin,VarMax,VarSize);
    pop(i).Cost=CostFunction(pop(i).Position); 
    pop(i).Rank=0;
    pop(i).Sort=0;
end
    pp=cat(2,pop.Cost);
    idealp=min(idealp,min(pp,[],2));   
    pop=reduce(pop,nPop,Direction,idealp);
    
    %%%%%%%%%%The main loop%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for it=1:MaxIt
    disp(['The iteration of Testproblem are : ', num2str(it)])
    % Selection,Crossover and Mutate 
    a1=randperm(nPop);
    a2=randperm(nPop);
    if mod(nPop,4)==0
        for i=1:4:nPop
            p1=BinaryTournamentSelection(pop(a1(i)),pop(a1(i+1)));
            p2=BinaryTournamentSelection(pop(a1(i+2)),pop(a1(i+3)));
            [childpop(i).Position,childpop(i+1).Position]=realbinarycrossover(p1,p2,VarRange,pCrossover);
            childpop(i).Position= realmutate(childpop(i),VarRange,pMutation);
            childpop(i+1).Position= realmutate(childpop(i+1),VarRange,pMutation);
            p1=BinaryTournamentSelection(pop(a2(i)),pop(a2(i+1)));
            p2=BinaryTournamentSelection(pop(a2(i+2)),pop(a2(i+3)));
            [childpop(i+2).Position,childpop(i+3).Position]=realbinarycrossover(p1,p2,VarRange,pCrossover);
            childpop(i+2).Position= realmutate(childpop(i),VarRange,pMutation);
            childpop(i+3).Position= realmutate(childpop(i+1),VarRange,pMutation);     
        end
    elseif mod(nPop,4)==2
        for i=1:4:(nPop-2)
            p1=BinaryTournamentSelection(pop(a1(i)),pop(a1(i+1)));
            p2=BinaryTournamentSelection(pop(a1(i+2)),pop(a1(i+3)));
            [childpop(i).Position,childpop(i+1).Position]=realbinarycrossover(p1,p2,VarRange,pCrossover);
            childpop(i).Position= realmutate(childpop(i),VarRange,pMutation);
            childpop(i+1).Position= realmutate(childpop(i+1),VarRange,pMutation);
            p1=BinaryTournamentSelection(pop(a2(i)),pop(a2(i+1)));
            p2=BinaryTournamentSelection(pop(a2(i+2)),pop(a2(i+3)));
            [childpop(i+2).Position,childpop(i+3).Position]=realbinarycrossover(p1,p2,VarRange,pCrossover);
            childpop(i+2).Position= realmutate(childpop(i),VarRange,pMutation);
            childpop(i+3).Position= realmutate(childpop(i+1),VarRange,pMutation);     
        end
            p1=BinaryTournamentSelection(pop(a1(nPop-1)),pop(a1(nPop)));
            p2=BinaryTournamentSelection(pop(a2(nPop-1)),pop(a2(nPop)));
            [childpop(nPop-1).Position,childpop(nPop).Position]=realbinarycrossover(p1,p2,VarRange,pCrossover);
            childpop(nPop-1).Position= realmutate(childpop(nPop-1),VarRange,pMutation);
            childpop(nPop).Position= realmutate(childpop(nPop),VarRange,pMutation);
    end
    for j=1:nPop
        childpop(j).Cost=CostFunction(childpop(j).Position); 
        pop(j).Rank=0;
        childpop(j).Rank=0;
        pop(j).Sort=0;
        childpop(j).Sort=0;
    end
    Mergepop=[pop;childpop];
    Cost=cat(2,Mergepop.Cost);
    idealp=min(idealp,min(Cost,[],2));
    
    %environmental selection
    pop=reduce(Mergepop,nPop,Direction,idealp);
    Mergepop=repmat(empty_individual,2*nPop,1);
    childpop=repmat(empty_individual,nPop,1);
end
    pareto=cat(2,pop.Cost);
    
    %performance test
    GD=converge(pareto,PFt);
    IGD=invertedGD(pareto,PFt);
    SP=spacing(pareto);
   % HV = sum(hypeIndicatorExact( pareto', bounds', -1 ));
    if objDim==2
        plot(pareto(1,:),pareto(2,:),'o');
        hold on 
        plot(PFt(:,1),PFt(:,2),'r.');
    else
        plot3(pareto(1,:),pareto(2,:),pareto(3,:),'o');
        hold on 
        plot3(PFt(:,1),PFt(:,2),PFt(:,3),'r.');   
    end

 
         
    
    


