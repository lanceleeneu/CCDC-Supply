function childpop=reduce(pop,n2,Direction,idealp)

    Merge=pop;
    Cost=cat(2,Merge.Cost);
    Sort=cat(2,Merge.Sort);
    Value=r2(Cost', idealp', Direction',Sort);
    r=1;
    for i=1:n2;
        [MaxValue,MaxIndex]=max(Value);
        if(MaxValue<=0)
            Cost=cat(2,Merge.Cost);
            Sort=cat(2,Merge.Sort);
            Value = r2(Cost', idealp', Direction',Sort);
            r=r+1;
        end
            pop(i)=Merge(MaxIndex);
            Value(MaxIndex)=-1;
            pop(i).Rank=r;
            Merge(MaxIndex).Sort=1;  
        
    end



    childpop=pop(1:n2);
end
        
        
    
