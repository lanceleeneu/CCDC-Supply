function [Position1,Position2]=realbinarycrossover(p1,p2,VarRange,pCrossover)

eta_c = 30;
EPS = 1.2e-7;
numVariables = size(p1.Position,2);
Position1=zeros(1,numVariables);
Position2=zeros(1,numVariables);
if (rand <= pCrossover)
    for i=1:numVariables
        if (rand <= 0.5)
            if (abs(p1.Position(i) - p2.Position(i)) > EPS)
                if (p1.Position(i) < p2.Position(i))
                    
                    y1 = p1.Position(i);
                    y2 = p2.Position(i);
                    
                else
                    y1 = p2.Position(i);
                    y2 = p1.Position(i);
                    
                end
                yl = VarRange(1,i);
                yu = VarRange(2,i);
                r = rand;
                beta = 1.0 + (2.0*(y1-yl)/(y2-y1));
                alpha = 2.0 - beta^(-(eta_c+1.0));
                if (r <= (1.0/alpha))
                    
                    betaq =(r*alpha)^(1.0/(eta_c+1.0));
                    
                else
                    
                    betaq = (1.0 / (2.0 - r * alpha))^ (1.0 / (eta_c + 1.0));
                end
                c1 = 0.5*((y1+y2)-betaq*(y2-y1));
                beta = 1.0 + (2.0*(yu-y2)/(y2-y1));
                alpha = 2.0 - beta^(-(eta_c + 1.0));
                if (r <= (1.0/alpha))
                    
                    betaq = (r * alpha)^ (1.0 / (eta_c + 1.0));
                    
                else
                    
                    betaq = (1.0 / (2.0 - r * alpha))^ (1.0 / (eta_c + 1.0));
                end
                c2 = 0.5*((y1+y2)+betaq*(y2-y1));
                if (c1<yl)
                    c1=yl;
                end
                if (c2<yl)
                    c2=yl;
                end
                if (c1>yu)
                    c1=yu;
                end
                if (c2>yu)
                    c2=yu;
                end
                if (rand<=0.5)
                    
                    Position1(i) = c2;
                    Position2(i) = c1;
                    
                else
                    
                    Position1(i) = c1;
                    Position2(i) = c2;
                    
                end
            else
                
                Position1(i) = p1.Position(i);
                Position2(i) = p2.Position(i);
                
            end
        else
            
            Position1(i) = p1.Position(i);
            Position2(i) = p2.Position(i);
            
        end
    end
else
    for i=1:numVariables
        
        Position1(i) = p1.Position(i);
        Position2(i) = p2.Position(i);
        
    end
end
end
