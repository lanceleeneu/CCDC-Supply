clc;
clear;
tic;
format long;
format compact;


problems={'63'};
%'WFG1','WFG2','WFG4','WFG5','WFG6','WFG7','WFG8','WFG9'
problem_length = length(problems);
totalrun       = 30;

for i = 1 : problem_length
    problem = problems{i};
    fprintf('Running on %s...\n', problem);
    for j = 1 : totalrun
        [SP,GD,IGD,pareto]=r2_MOGA(problem);
        eval(['save pareto_3_' num2str(j) ' pareto']);
        %eval(['save GD_' num2str(i) '_' num2str(j) ' GD']);
        eval(['save GD_3_' num2str(j) ' GD']);
        eval(['save IGD_3_' num2str(j) ' IGD']);
        %eval(['save HV_' sprintf(problems{i}) '_' num2str(j) ' HV']);
        eval(['save SP_3_' num2str(j) ' SP']);
    end
end

toc;