%% DTLZ1 Test Suite
% Analyze the Multifrontal multiobjective optimization problems, the
% problem has 11^k-1 local Pareto front and linear hyperplane in the test.

function z=MyCost11(x)

    [num,dim]=size(x);

    g=100*(dim-2)+100*sum((x(num,3:dim)-repmat(0.5,[num dim-2])).^2-cos(20*pi*(x(num,3:dim)-repmat(0.5,[num dim-2]))));

    z1=0.5*(1+g)*x(:,1).*x(:,2);
    z2=0.5*(1+g)*x(:,1).*(1-x(:,2));
    z3=0.5*(1+g)*(1-x(:,1));

    z=[z1;z2;z3];
end 