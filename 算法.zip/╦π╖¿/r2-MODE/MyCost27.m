%% UF7 benchmark function
function z=MyCost27(x)

    [num, dim]  = size(x);
    Y           = zeros(num,dim);
    Y(:,2:dim)  = (x(:,2:dim) - sin(6.0*pi*repmat(x(:,1),[1,dim-1]) + pi/dim*repmat((2:dim),[num,1]))).^2;
    tmp1        = sum(Y(:,3:2:dim));  % odd index
    tmp2        = sum(Y(:,2:2:dim));  % even index
    tmp         = (x(:,1)).^0.2;
    z1      = tmp       + 2.0*tmp1/size(3:2:dim,2);
    z2      = 1.0 - tmp + 2.0*tmp2/size(2:2:dim,2);
 
     z=[z1;z2];
    
end      
  