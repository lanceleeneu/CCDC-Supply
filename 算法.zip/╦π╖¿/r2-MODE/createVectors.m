function weights = createVectors(s, d)
c = 1; 
num = nchoosek(s+d-1,d-1);
weights = zeros(num, d);
i = 1;
while i <= (s+1).^d    
    count = int2kary(i,s+1,d);
    loopSum = sum(count);
    if loopSum == s	
        weights(c,:) = count./s;        
        c = c+1;
    end
    i = i+1;
end
end

function kary = int2kary(x, basek, digits)
val = digits-1;
kary = zeros(1, digits);
i = 1;
while x
    if x >= basek.^val
        kary(i) = kary(i)+1;
	    x = x - basek.^val;
    else
        val = val-1;
	    i = i+1;
    end;
end;
end 