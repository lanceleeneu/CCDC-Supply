%% DTLZ6 Test Suite
% test the problem convergence the hard curve
function z=MyCost16(x)

    [num,dim]=size(x);

    g=sum(x(num,3:dim).^(0.1));   

%    z1=(1+g).*cos(0.5*pi*x(:,1)).*cos(0.5*pi*(1+2*g*x(:,2))/(4*(1+g)));
    z1=(1+g).*cos(0.5*pi*x(:,1)).*cos(pi*(1+2*g*x(:,2))/(4*(1+g)));
    z2=(1+g).*cos(0.5*pi*x(:,1)).*sin(pi*(1+2*g*x(:,2))/(4*(1+g)));
    z3=(1+g).*sin(0.5*pi*x(:,1));
    
    z=[z1;z2;z3];
end 