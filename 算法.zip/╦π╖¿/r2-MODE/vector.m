function wts=vector(k,n)
% %for l=1:10
% tic;
% n=15,k=100;
wts=[eye(n,n);rand(k-n,n)];

mag=sqrt(sum((wts.*wts)' )');
wts=wts./mag(:,ones(1,n));
%      VectorValue=wts(i,:)*wts';
%      VectorValue=sqrt(2-2* VectorValue);
%      VectorValue(i)=[];
%      Vectorsum(i)=sum(1./VectorValue);
% end
for j=1:10000
    VectorValue=wts*wts'-eye(k);
    VectorValue=1./(2-2* VectorValue);
    VectorValue=VectorValue-diag(diag(VectorValue));
    %VectorValue=1./VectorValue;
    wtstemp=sum(VectorValue);
    [a,ind]=sort(wtstemp);
    wts(ind(k),:)=rand(1,n);
    wts(ind(k),:)=wts(ind(k),:)/norm(wts(ind(k),:));
end
% toc;
% time(l)=toc;
%end

