% computes the R2 indicator value for a set of points and rank of the populations

function value = r2(points, ideal, weights,Sort)
% check input
[n,d] = size(points);
[m,dm] = size(ideal);
if (d < 1 ) || (d ~= dm)
    error('dimensions of point matrix and ideal point must be equal and > 1');
end;
ideals = repmat(ideal, n, 1);
normalizedPoints = points - ideals;
N = size(weights, 1);
minUtility = zeros(N,1);
minUtilityPoints=inf(N,1);
for i = 1:N
    currWeights = repmat(weights(i,:), n, 1);
    currWeights = currWeights .* normalizedPoints;
    utilityPoints = max(currWeights, [], 2);
    utilityPoints(Sort'==1)=inf; 
    [minUtilityPoints(i),minUtility(i)] = min(utilityPoints);
end;
        
value=zeros(n,1);
for i=1:N
    value(minUtility(i)) =value(minUtility(i))+minUtilityPoints(i); 
end

