%% DTLZ2 Test Suite
function z=MyCost43(x)

    [num,dim]=size(x);

    g=sum(x(num,10:dim).^2);

    z1=(1+g).*cos(0.5*pi*x(:,1)).*cos(0.5*pi*x(:,2)).*cos(0.5*pi*x(:,3)).*cos(0.5*pi*x(:,4)).*cos(0.5*pi*x(:,5)).*cos(0.5*pi*x(:,6)).*cos(0.5*pi*x(:,7)).*cos(0.5*pi*x(:,8)).*cos(0.5*pi*x(:,9));
    z2=(1+g).*cos(0.5*pi*x(:,1)).*cos(0.5*pi*x(:,2)).*cos(0.5*pi*x(:,3)).*cos(0.5*pi*x(:,4)).*cos(0.5*pi*x(:,5)).*cos(0.5*pi*x(:,6)).*cos(0.5*pi*x(:,7)).*cos(0.5*pi*x(:,8)).*sin(0.5*pi*x(:,9));
    z3=(1+g).*cos(0.5*pi*x(:,1)).*cos(0.5*pi*x(:,2)).*cos(0.5*pi*x(:,3)).*cos(0.5*pi*x(:,4)).*cos(0.5*pi*x(:,5)).*cos(0.5*pi*x(:,6)).*cos(0.5*pi*x(:,7)).*sin(0.5*pi*x(:,8));
    z4=(1+g).*cos(0.5*pi*x(:,1)).*cos(0.5*pi*x(:,2)).*cos(0.5*pi*x(:,3)).*cos(0.5*pi*x(:,4)).*cos(0.5*pi*x(:,5)).*cos(0.5*pi*x(:,6)).*sin(0.5*pi*x(:,7));
    z5=(1+g).*cos(0.5*pi*x(:,1)).*cos(0.5*pi*x(:,2)).*cos(0.5*pi*x(:,3)).*cos(0.5*pi*x(:,4)).*cos(0.5*pi*x(:,5)).*sin(0.5*pi*x(:,6));
    z6=(1+g).*cos(0.5*pi*x(:,1)).*cos(0.5*pi*x(:,2)).*cos(0.5*pi*x(:,3)).*cos(0.5*pi*x(:,4)).*sin(0.5*pi*x(:,5));
    z7=(1+g).*cos(0.5*pi*x(:,1)).*cos(0.5*pi*x(:,2)).*cos(0.5*pi*x(:,3)).*sin(0.5*pi*x(:,4));
    z8=(1+g).*cos(0.5*pi*x(:,1)).*cos(0.5*pi*x(:,2)).*sin(0.5*pi*x(:,3));
    z9=(1+g).*cos(0.5*pi*x(:,1)).*sin(0.5*pi*x(:,2));
    z10=(1+g).*sin(0.5*pi*x(:,1));

    z=[z1;z2;z3;z4;z5;z6;z7;z8;z9;z10];
end 