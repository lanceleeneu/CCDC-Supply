%% UF8 benchmark function
function z=MyCost28(x)
    [num, dim]  = size(x);
    Y           = zeros(num,dim);
    Y(:,3:dim)  = x(:,3:dim) - 2.0*repmat(x(:,2),[1,dim-2]).*sin(2.0*pi*repmat(x(:,1),[1,dim-2]) + pi/dim*repmat((3:dim),[num,1]));
    H           = zeros(num,dim);
    H(:,3:dim)  = 4.0*Y(:,3:dim).^2 - cos(8.0*pi*Y(:,3:dim)) + 1.0;
    tmp1        = sum(H(:,4:3:dim));  % j-1 = 3*k
    tmp2        = sum(H(:,5:3:dim));  % j-2 = 3*k
    tmp3        = sum(H(:,3:3:dim));  % j-0 = 3*k
    z1      = cos(0.5*pi*x(:,1)).*cos(0.5*pi*x(:,2)) + 2.0*tmp1/size(4:3:dim,2);
    z2      = cos(0.5*pi*x(:,1)).*sin(0.5*pi*x(:,2)) + 2.0*tmp2/size(5:3:dim,2);
    z3      = sin(0.5*pi*x(:,1))                     + 2.0*tmp3/size(3:3:dim,2);
   
     z=[z1;z2;z3];
    
end      
  