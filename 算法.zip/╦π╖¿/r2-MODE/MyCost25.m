%% UF5 benchmark function
function z=MyCost25(x)

    N           = 10.0;
    E           = 0.1;
    [num, dim]  = size(x);
    Y           = zeros(num,dim);
    Y(:,2:dim)  = x(:,2:dim) - sin(6.0*pi*repmat(x(:,1),[1,dim-1]) + pi/dim*repmat((2:dim),[num,1]));
    H           = zeros(num,dim);
    H(:,2:dim)  = 2.0*Y(:,2:dim).^2 - cos(4.0*pi*Y(:,2:dim)) + 1.0;
    tmp1        = sum(H(:,3:2:dim));  % odd index
    tmp2        = sum(H(:,2:2:dim));  % even index
    tmp         = (0.5/N+E)*abs(sin(2.0*N*pi*x(:,1)));
    z1      = x(:,1)      + tmp + 2.0*tmp1/size(3:2:dim,2);
    z2      = 1.0 - x(:,1)+ tmp + 2.0*tmp2/size(2:2:dim,2);

     
     z=[z1;z2];
    
end      
  