%% DTLZ4 Test Suite
% Similar to DTLZ2 and test diversity of the algorithm

function z=MyCost71(x)

    [num,dim]=size(x);

    g=sum((x(num,3:dim)-0.5).^2);

    z1=(1+g).*cos(0.5*pi*x(:,1).^100).*cos(0.5*pi*x(:,2).^100).*cos(0.5*pi*x(:,3).^100).*cos(0.5*pi*x(:,4).^100);
    z2=(1+g).*cos(0.5*pi*x(:,1).^100).*cos(0.5*pi*x(:,2).^100).*cos(0.5*pi*x(:,3).^100).*sin(0.5*pi*x(:,4).^100);
    z3=(1+g).*cos(0.5*pi*x(:,1).^100).*cos(0.5*pi*x(:,2).^100).*sin(0.5*pi*x(:,3).^100);
    z4=(1+g).*cos(0.5*pi*x(:,1).^100).*sin(0.5*pi*x(:,2).^100);
    z5=(1+g).*sin(0.5*pi*x(:,1).^100);
    z=[z1;z2;z3;z4;z5];
end 