%% DTLZ3 Test Suite
% The modification of DTLZ2 and the g function is as the same as the DTLZ1
% 3^K -1 local Pareto front in this test.

function z=MyCost13(x)

    [num,dim]=size(x);

    g=100*(dim-2)+100*sum((x(num,3:dim)-repmat(0.5,[num dim-2])).^2-cos(20*pi*(x(num,3:dim)-repmat(0.5,[num dim-2]))));

    z1=(1+g).*cos(0.5*pi*x(:,1)).*cos(0.5*pi*x(:,2));
    z2=(1+g).*cos(0.5*pi*x(:,1)).*sin(0.5*pi*x(:,2));
    z3=(1+g).*sin(0.5*pi*x(:,1));

    z=[z1;z2;z3];
end 