%% ZDT1 benchmark function
function z=MyCost1(x)
        
        
        xv=x(:,2:30);
        gx=1+9*(sum(xv,2)/29);

        z1=x(:,1);
        z2=gx.*(1-sqrt(x(:,1)./gx));
        z=[z1;z2];
    
end      
  