function childpop=reduce(pop,n2,Direction,idealp)

    Merge=pop;
    Cost=cat(2,Merge.Cost);
    Sort=cat(2,Merge.Sort);
    Value=r2(Cost', idealp', Direction',Sort);
    r=1;
%     while(i<=n2)
%         MaxIndex=-1;
%         for j=1:n
%             if Value(j)~=-1
%                 if MaxIndex==-1
%                     MaxIndex=j;
%                 else
%                     [MaxValue,MaxIndex]=max(Value);
%                 end
%             end
%         end
%         if(MaxValue~=0)
%             pop(i)=Merge(MaxIndex);
%             Value(MaxIndex)=-1;
%             pop(i).Rank=r;
%             Merge(MaxIndex).Sort=1;
%         else
%             Cost=cat(2,Merge.Cost);
%             Sort=cat(2,Merge.Sort);
%             Value = r2(Cost', idealp', Direction',Sort);
%             r=r+1;
%             temp=1;
%         end
%         i=i-temp;
%         temp=0;
%         i=i+1;
%     end
    for i=1:n2;
        [MaxValue,MaxIndex]=max(Value);
        if(MaxValue<=0)
            Cost=cat(2,Merge.Cost);
            Sort=cat(2,Merge.Sort);
            Value = r2(Cost', idealp', Direction',Sort);
            r=r+1;
        end
            pop(i)=Merge(MaxIndex);
            Value(MaxIndex)=-1;
            pop(i).Rank=r;
            Merge(MaxIndex).Sort=1;  
        
    end



    childpop=pop(1:n2);
end
        
        
    
