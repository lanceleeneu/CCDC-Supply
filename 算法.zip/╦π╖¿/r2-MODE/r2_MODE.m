function [SP,GD,IGD,pareto]=r2_MODE(Testproblem)
%% Problem definition 
format long
disp(['The MOPs of Testproblem are : ', num2str(Testproblem)])

switch Testproblem
    case 'Furnace'
        CostFunction = @(x)Furnace(x);
        nVar=3;
        objDim = 2;
        VarMin=[669.4898 3.0734 -0.1] ;
        VarMax=[969.4898 10.0734 0];
        
%%%%%%%%%%%%%%%---ZDT Test Suite---%%%%%%%%%%%%%%%%%%               
    case 'ZDT1'
        CostFunction = @(x)MyCost1(x);
        nVar=30;
        objDim=2;
        VarMin=zeros(1,nVar);
        VarMax=ones(1,nVar);
        bounds=[2 2];
        load 'PFture_data\ZDT1PFt.mat';
    case 'ZDT2'
        CostFunction = @(x)MyCost2(x);
        nVar=30;
        objDim=2;
        VarMin=zeros(1,nVar);
        VarMax=ones(1,nVar);
        bounds=[2 2];
        load 'PFture_data\ZDT2PFt.mat';
    case 'ZDT3'
        CostFunction = @(x)MyCost3(x);
        nVar=30;
        objDim=2;
        VarMin=zeros(1,nVar);
        VarMax=ones(1,nVar);
        bounds=[2 2];
        load 'PFture_data\ZDT3PFt.mat';
    case 'ZDT4'
        CostFunction = @(x)MyCost4(x); 
        nVar=10;
        objDim=2;
        VarMin=[0 -5 -5 -5 -5 -5 -5 -5 -5 -5] ;
        VarMax=[1 5 5 5 5 5 5 5 5 5];
        bounds=[10 10];
        load 'PFture_data\ZDT4PFt.mat';
    case 'ZDT6'
        CostFunction = @(x)MyCost6(x);
        nVar=10;
        objDim=2;
        VarMin=zeros(1,nVar);
        VarMax=ones(1,nVar);
        bounds=[10 10];
        load 'PFture_data\ZDT6PFt.mat';
%%%%%%%%%%%%%%%---DTLZ Test Suite---%%%%%%%%%%%%%%%%%%
    case 'DTLZ1'
        CostFunction = @(x)MyCost115(x);
        nVar=7;
        objDim=5;
        VarMin=zeros(1,nVar);
        VarMax=ones(1,nVar);
        bounds=[1 1 1];
        load 'PFture_data\DTLZ1_5_210.mat';
    case 'DTLZ2'
        CostFunction = @(x)MyCost12(x);
        nVar=12;
        objDim=3;
        VarMin=zeros(1,nVar);
        VarMax=ones(1,nVar);
        bounds=[2 2 2];
        load 'PFture_data\DTLZ2_5_210.mat';
    case 'DTLZ3'
        CostFunction = @(x)MyCost13(x);
        nVar=12;
        objDim=3;
        VarMin=zeros(1,nVar);
        VarMax=ones(1,nVar);
        bounds=[7  7  7];
        load 'PFture_data\DTLZ3_5_210.mat';
    case 'DTLZ4'
        CostFunction = @(x)MyCost14(x);
        nVar=12;
        objDim=3;
        VarMin=zeros(1,nVar);
        VarMax=ones(1,nVar);
        bounds=[10  10  10];
        load 'PFture_data\DTLZ4_5_210.mat';
    case 'DTLZ5'
        CostFunction = @(x)MyCost15(x);
        nVar=12;
        objDim=3;
        VarMin=zeros(1,nVar);
        VarMax=ones(1,nVar);
        bounds=[4  4  4];
        load 'PFture_data\DTLZ5PFt.mat';
    case 'DTLZ6'
        CostFunction = @(x)MyCost16(x);
        nVar=12;
        objDim=3;
        VarMin=zeros(1,nVar);
        VarMax=ones(1,nVar);
        bounds=[11 11 11];
        load 'PFture_data\DTLZ6PFt.mat';
    case 'DTLZ7'
        CostFunction = @(x)MyCost17(x);
        nVar=22;
        objDim=3;
        VarMin=zeros(1,nVar);
        VarMax=ones(1,nVar);
        bounds=[21 21 21];
        load 'PFture_data\DTLZ7PFt.mat';
%%%%%%%%%%%%%%%---UF Test Suite---%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    case 'UF1'
        CostFunction=@(x)MyCost21(x);     % UF1 benchmark function
        nVar=10;
        objDim=2;
        VarMin=[zeros(1,1) -ones(1,nVar-1)];
        VarMax=ones(1,nVar);
        load 'PFture_data\UF1PFt.mat';
    case 'UF2'
        CostFunction=@(x)MyCost22(x);    % UF2 benchmark function
        nVar=10;
        objDim=2;
        VarMin=[zeros(1,1) -ones(1,nVar-1)];
        VarMax=ones(1,nVar);
        load 'PFture_data\UF2PFt.mat';
    case 'UF3'
        CostFunction=@(x)MyCost23(x);   % UF3 benchmark function
        nVar=10;
        objDim=2;
        VarMin=zeros(1,nVar);
        VarMax=ones(1,nVar);
        load 'PFture_data\UF3PFt.mat';
    case 'UF4'
        CostFunction=@(x)MyCost24(x);  % UF4 benchmark function
        nVar=10;
        objDim=2;
        VarMin=[zeros(1,1) -2*ones(1,nVar-1)];
        VarMax=2*ones(1,nVar);
        load 'PFture_data\UF4PFt.mat';
    case 'UF5'
        CostFunction=@(x)MyCost25(x);   % UF5 benchmark function
        nVar=10;
        objDim=2;
        VarMin=[zeros(1,1) -ones(1,nVar-1)];
        VarMax=ones(1,nVar);
        load 'PFture_data\UF5PFt.mat';
    case 'UF6'
        CostFunction=@(x)MyCost26(x);  % UF6 benchmark function
        nVar=10;
        objDim=2;
        VarMin=[zeros(1,1) -ones(1,nVar-1)];
        VarMax=ones(1,nVar);
        load 'PFture_data\UF6PFt.mat';
    case 'UF7'
        CostFunction=@(x)MyCost27(x);  % UF7 benchmark function
        nVar=10;
        objDim=2;
        VarMin=[zeros(1,1) -ones(1,nVar-1)];
        VarMax=ones(1,nVar);
        load 'PFture_data\UF7PFt.mat';
%%%%%%%%%%% UF Test Suite  (Three objective optimization)  %%%%%%%%%%%%%%%%
    case 'UF8'
        CostFunction=@(x)MyCost28(x);   % UF8 benchmark function
        nVar=10;
        objDim=3;
        VarMin=[zeros(1,2) -2*ones(1,nVar-2)];
        VarMax=[ones(1,2) 2*ones(1,nVar-2)];
        load 'PFture_data\UF8PFt.mat';
    case 'UF9'
        CostFunction=@(x)MyCost29(x);   % UF9 benchmark function
        nVar=10;
        objDim=3;
        VarMin=[zeros(1,2) -2*ones(1,nVar-2)];
        VarMax=[ones(1,2) 2*ones(1,nVar-2)];
        load 'PFture_data\UF9PFt.mat';
    case 'UF10'
        CostFunction=@(x)MyCost30(x);  % UF10 benchmark function
        nVar=10;
        objDim=3;
        VarMin=[zeros(1,2) -2*ones(1,nVar-2)];
        VarMax=[ones(1,2) 2*ones(1,nVar-2)];
        load 'PFture_data\UF10PFt.mat'; 
 %%%%%%%%%%% WFG Test Suite  %%%%%%%%%%%%%%%%       
 case 'WFG1'
        CostFunction=@(x)MyCost31(x);  % WFG1 benchmark function
        nVar=24;
        objDim=3;
        VarMin=zeros(1,nVar);
        VarMax=2*(1:nVar);
        bounds=[3 5 7];
        load 'PFture_data\WFG1_3DPFt.mat';  
    case 'WFG2'
        CostFunction=@(x)MyCost32(x);  % WFG2 benchmark function
        nVar=24;
        objDim=3;
        VarMin=zeros(1,nVar);
        VarMax=2*(1:nVar);
        bounds=[3 5 7];
        load 'PFture_data\WFG2_3DPFt.mat';  
    case 'WFG3'
        CostFunction=@(x)MyCost33(x);  % WFG3 benchmark function
        nVar=24;
        objDim=3;
        VarMin=zeros(1,nVar);
        VarMax=2*(1:nVar);
        bounds=[3 5 7];
        load 'PFture_data\WFG3_3DPFt.mat';  
    case 'WFG4'
        CostFunction=@(x)MyCost34(x);  % WFG4 benchmark function
        nVar=24;
        objDim=3;
        VarMin=zeros(1,nVar);
        VarMax=2*(1:nVar);
        bounds=[3 5 7];
        load 'PFture_data\WFG4_3DPFt.mat';  
    case 'WFG5'
        CostFunction=@(x)MyCost35(x);  % WFG5 benchmark function
        nVar=24;
        objDim=3;
        VarMin=zeros(1,nVar);
        VarMax=2*(1:nVar);
        bounds=[3 5 7];
        load 'PFture_data\WFG5_3DPFt.mat';  
    case 'WFG6'
        CostFunction=@(x)MyCost36(x);  % WFG6 benchmark function
        nVar=24;
        objDim=3;
        VarMin=zeros(1,nVar);
        VarMax=2*(1:nVar);
        bounds=[3 5 7];
        load 'PFture_data\WFG6_3DPFt.mat';  
    case 'WFG7'
        CostFunction=@(x)MyCost37(x);  % WFG7 benchmark function
        nVar=24;
        objDim=3;
        VarMin=zeros(1,nVar);
        VarMax=2*(1:nVar);
        bounds=[3 5 7];
        load 'PFture_data\WFG7_3DPFt.mat';  
    case 'WFG8'
        CostFunction=@(x)MyCost38(x);  % WFG8 benchmark function
        nVar=24;
        objDim=3;
        VarMin=zeros(1,nVar);
        VarMax=2*(1:nVar);
        bounds=[3 5 7];
        load 'PFture_data\WFG8_3DPFt.mat';  
    case 'WFG9'
        CostFunction=@(x)MyCost39(x);  % WFG9 benchmark function
        nVar=24;
        objDim=3;
        VarMin=zeros(1,nVar);
        VarMax=2*(1:nVar);
        bounds=[3 5 7];
        load 'PFture_data\WFG9_3DPFt.mat';    

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  problems %%%%%%%%%%%
    case '41'
        CostFunction=@ (x)MyCost41(x);
        nVar=14;
        objDim=5;
        VarMin=zeros(1,nVar);
        VarMax=ones(1,nVar);
     load 'PFture_data\DTLZ1_5_210.mat';
    case '42'
        CostFunction=@ (x)MyCost42(x);
        nVar=17;
        objDim=8;
        VarMin=zeros(1,nVar);
        VarMax=ones(1,nVar);
       load 'PFture_data\DTLZ1_8_156.mat';
    case '43'
        CostFunction=@ (x)MyCost43(x);
        nVar=19;
        objDim=10;
        VarMin=zeros(1,nVar);
        VarMax=ones(1,nVar);
       load 'PFture_data\DTLZ1_10_275.mat';   
    case '44'
        CostFunction=@ (x)MyCost44(x);
        nVar=24;
        objDim=15;
        VarMin=zeros(1,nVar);
        VarMax=ones(1,nVar);
        load 'PFture_data\DTLZ1_15_135.mat';
     case '51'
        CostFunction=@ (x)MyCost51(x);
        nVar=9;
        objDim=5;
        VarMin=zeros(1,nVar);
        VarMax=ones(1,nVar);
     load 'PFture_data\DTLZ1_5_210.mat';
    case '52'
        CostFunction=@ (x)MyCost42(x);
        nVar=12;
        objDim=8;
        VarMin=zeros(1,nVar);
        VarMax=ones(1,nVar);
        load 'PFture_data\DTLZ1_8_156.mat';
    case '53'
        CostFunction=@ (x)MyCost43(x);
        nVar=14;
        objDim=10;
        VarMin=zeros(1,nVar);
        VarMax=ones(1,nVar);
        load 'PFture_data\DTLZ2_10_275.mat'; 
        case '61'
        CostFunction=@ (x)MyCost51(x);
        nVar=14;
        objDim=5;
        VarMin=zeros(1,nVar);
        VarMax=ones(1,nVar);
     load 'PFture_data\DTLZ3_5_210.mat';
    case '62'
        CostFunction=@ (x)MyCost42(x);
        nVar=17;
        objDim=8;
        VarMin=zeros(1,nVar);
        VarMax=ones(1,nVar);
    load 'PFture_data\DTLZ3_8_156.mat';
    case '63'
        CostFunction=@ (x)MyCost43(x);
        nVar=19;
        objDim=10;
        VarMin=zeros(1,nVar);
        VarMax=ones(1,nVar);
       load 'PFture_data\DTLZ3_10_275.mat';
       case '71'
        CostFunction=@ (x)MyCost51(x);
        nVar=14;
        objDim=5;
        VarMin=zeros(1,nVar);
        VarMax=ones(1,nVar);
     load 'PFture_data\DTLZ4_5_210.mat';
    case '72'
        CostFunction=@ (x)MyCost42(x);
        nVar=17;
        objDim=8;
        VarMin=zeros(1,nVar);
        VarMax=ones(1,nVar);
    load 'PFture_data\DTLZ4_8_156.mat';
    case '73'
        CostFunction=@ (x)MyCost43(x);
        nVar=19;
        objDim=10;
        VarMin=zeros(1,nVar);
        VarMax=ones(1,nVar);
       load 'PFture_data\DTLZ4_10_275.mat';  
end
VarRange=[VarMin;VarMax];
VarSize=[1,nVar];
nobj=numel(CostFunction(zeros(1,nVar)));    % number of objective functions

%% Parameter setting
if objDim==2
    nPop=100;
    H=99;
else
    if objDim==3
    nPop=300;
    H=23;
    else 
        nPop=220;
    end
end
MaxIt=1000;                   % generation size

CR=0.5;
F=0.5;
%% Initializing the population and the direction of dMOPSO-DE or R2-MOPSO
% Initializing the direction vector and the reference point
%%%%%%r2_MODE uses the createVectors to generate weight vectors%%%%%%
%   Direction=createVectors(12,9);
 %load 'c210-5.mat';
 %Direction=weights;
%   load 'v156-8.mat';
%   Direction=wts;
%  load 'c220-10.mat';
%  Direction=weights;
  
%%%% vspace is another weight generation not the direction vector, the improved r2_MODE uses the createVectors to generate weight vectors%%%%%%%  
  Direction=vector(nPop,objDim);
  Direction=(ones(nPop,objDim)./(Direction+1e-5))./(repmat((sum(ones(nPop,objDim)./(Direction+1e-5),2)),1,objDim));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Direction=Direction';

%% Initialize the population

empty_individual.Position=[];
empty_individual.Cost=[];
empty_individual.Rank=[];
empty_individual.Sort=[];
pop=repmat(empty_individual,nPop,1);
childpop=repmat(empty_individual,nPop,1);
Mergepop=repmat(empty_individual,2*nPop,1);
idealp=inf*ones(objDim,1);
for i=1:nPop
    pop(i).Position=unifrnd(VarMin,VarMax,VarSize);
    pop(i).Cost=CostFunction(pop(i).Position); 
    pop(i).Rank=0;
    pop(i).Sort=0;
end
    pp=cat(2,pop.Cost);
    idealp=min(idealp,min(pp,[],2));   
    pop=reduce(pop,nPop,Direction,idealp);
    
    %%%%%%%%%%The main loop%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for it=1:MaxIt
    disp(['The iteration of Testproblem are : ', num2str(it)])
    % Selection and Crossover
    for i=1:nPop
        r1=i;
        r2=i;
        r3=i;
        while(r1==i)
            r1=randi(nPop);
        end
        while(r2==i||r2==r1)
            r2=randi(nPop);
        end
        while(r3==i||r3==r1||r3==r2)
            r3=randi(nPop);
        end
        jrand=randi(nVar);
        for j=1:nVar
            if(rand<CR||j==jrand)
                childpop(i).Position(j)=pop(r3).Position(j)+F*(pop(r1).Position(j)-pop(r2).Position(j));
            else
                childpop(i).Position(j)=pop(i).Position(j);
            end
        end
        childpop(i).Position=min(max(childpop(i).Position,VarMin),VarMax);
    end
    for j=1:nPop
        childpop(j).Cost=CostFunction(childpop(j).Position); 
        pop(j).Rank=0;
        childpop(j).Rank=0;
        pop(j).Sort=0;
        childpop(j).Sort=0;
    end
    Mergepop=[pop;childpop];
    Cost=cat(2,Mergepop.Cost);
    idealp=min(idealp,min(Cost,[],2));
    
    %environmental selection
    pop=reduce(Mergepop,nPop,Direction,idealp);
    Mergepop=repmat(empty_individual,2*nPop,1);
    childpop=repmat(empty_individual,nPop,1);
end
    pareto=cat(2,pop.Cost);
    
    %performance test
    GD=converge(pareto,PFt);
    IGD=invertedGD(pareto,PFt);
    %HV = sum(hypeIndicatorExact( pareto', bounds', -1 ));
    SP=spacing(pareto);
%     if objDim==2
%         plot(pareto(1,:),pareto(2,:),'o');
%         hold on 
%         plot(PFt(:,1),PFt(:,2),'r.');
%     else
%         plot3(pareto(1,:),pareto(2,:),pareto(3,:),'o');
%         hold on 
%         plot3(PFt(:,1),PFt(:,2),PFt(:,3),'r.');   
%     end

 
         
    
    


