%% ZDT2 benchmark function
function z=MyCost2(x)
        
        
        xv=x(:,2:30);
        gx=1+9*(sum(xv,2)/29);

        z1=x(:,1);

        z2=gx.*(1-(x(:,1)./gx).^2);
        z=[z1;z2];
    
end      
  