function s=spacing(PF)
[NP,nn]=size(PF);

% [y,I]=sort(PF(:,1));
% 
% for i=1:NP     PFc(i,:)=PF(I(i),:); end
% 
% for i=1:NP-1   d(i)=norm(PF(i,:)-PF(i+1,:)); end
% md=mean(d);
% 
% for i=1:NP-1 x(i)=abs(d(i)-md); end
% delta=(df+dl+sum(x))/(df+dl+(NP-1).*md);
for i=1:nn
    for j=1:nn
        if(i==j)
            dj(j)=inf;
        else
            dj(j)=norm(PF(:,i)-PF(:,j));
        end
    end
    di(i)=min(dj);
end
md=mean(di);
s=sqrt(sum((di-md).^2)/(nn-1));
    
        
         
