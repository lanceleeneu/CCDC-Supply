%% WFG3 benchmark function
%
% non-Separable unimodal, linear and degenerate pareto front.
%
% Ref: Huband S, Hingston P, Barone L, While L, 2006, A review
%      of multiobjective test problems and a scalable test problem
%      toolkit. IEEE Transactions on Evolutionary Computation,
%      10(5), pp477-506.

function F=MyCost33(x)

    if nargin ~=1
        error('One input is required.');
    end 
    M=3;
    k = 4;
    l = 20;
    n = length(x);
    Z = x./(2*[1:n]);
    S = 2*(1:M);
    A = [1 zeros(1,M-2)];
    h = ones(1,M);
    D = 1;
    
y1 = Z;

t1(1:k) = y1(1:k);
for i = k+1:n
    t1(i) = s_linear(y1(i),0.35);
end

y2 = t1;
t2(1:k) = y2(1:k);

% keyboard
for i = k+1:k+l/2
    t2(i) = r_nonsep([y2(k+2*(i-k)-1) y2(k+2*(i-k))],2);
end
 

y3 = t2;

for i = 1:M-1
    Y = y3((i-1)*k/(M-1)+1:(i*k/(M-1)));
    W = ones(1,length(Y));
    t3(i) = r_sum(Y,W);
end

Y = y3(k+1:k+l/2);
W = ones(1,length(Y));
t3(M) = r_sum(Y,W);

for i = 1:M-1
    X(i) = max(t3(M),A(i))*(t3(i)-0.5)+0.5;
end
X(M) = t3(M);
H = zeros(1,M);
for i = 1:M
    switch(h(i));
        case 1
            H(i) = eval_linear(X,i);
        case 2
            H(i) = eval_mixed(X,i,alphac,Am);
        case 3
            H(i) = eval_convex(X,i);
        case 4
            H(i) = eval_disc(X,i,alphac,betac,Am);
    end
end
    
    dd = D*X(M) + S.*H;
    F = dd';

end

%%%%%%%%%%%%%%%%%%%%%%%%%%% subfunction of WFG %%%%
%%%%% shape function 
function fl = eval_linear(x,m)

M = length(x);

if m == 1
    fl = prod(x(1:M-1));
elseif m>=2 && m < M
    fl = (prod(x(1:M-m))) * (1-x(M-m+1));
else
    fl = 1-x(1);
end
fl = correct_to_01(fl);
return
end 

function fl = eval_convex(x,m)

M = length(x);

if m == 1
    fl = prod(1-cos(x(1:M-1)*pi/2));
elseif m>=2 && m < M
    fl = (prod((1-cos(x(1:M-m)*pi/2)))) * (1-sin(x(M-m+1)*pi/2));
else
    fl = 1-sin(x(1)*pi/2);
end
fl = correct_to_01(fl);
return
end 

function fl=eval_concave(x,m)

M=length(x);

if m==1
    fl=prod(sin(x(1:M-1)*pi/2));
elseif m>=2 && m<M
    fl=(prod(sin(x(1:M-m)*pi/2)))*cos(x(M-m+1)*pi/2);
else 
    fl=cos(x(1)*pi/2);
end 
fl=correct_to_01(fl);

return
end 

function fm = eval_mixed(x,m,alphac,Am)

M = length(x);
assert(m==M);
fm = (1-x(1)-cos(2*Am*pi*x(1)+pi/2)/(2*Am*pi))^alphac;
fm = correct_to_01(fm);
return
end 

function fd = eval_disc(x,m,alphac,betac,Am)
M = length(x);
assert(m == M);

fd = 1 - (x(1)^alphac) * (cos(Am*(x(1)^betac)*pi))^2;
fd = correct_to_01(fd);
return
end 

%%%%% Bias function
function f = b_poly(y,a)
f = correct_to_01(y^a);

return
end 

function f = b_flat(y,A,B,C)
f = A + min(0,floor(y-B)) * A * (B-y)/B - ...
    min(0,floor(C-y)) * (1-A) * (y-C) / (1-C);
f = correct_to_01(f);

return
end 

function f = b_param(y,Y,A,B,C)
if Y<=0.5
    U = B+2*Y*(C-B)*A;
else 
    U = B+(C-B)*A + (C-(B+(C-B)*A))*(Y-0.5)*2;
end
V = A-(1-2*U)*abs(floor(0.5-U)+A);
f = correct_to_01(y^(B+(C-B)*V));
return
end

%%%% Shift function 
function f = s_linear(y,A)
f = abs(y-A)/abs(floor(A-y)+A);
f = correct_to_01(f);
return
end 

function f = s_decept(y,A,B,C)
f = 1+(abs(y-A)-B)*(floor(y-A+B)*(1-C+(A-B)/B)/(A-B) + floor(A+B-y)*(1-C+(1-A-B)/B)/(1-A-B)+1/B);
f = correct_to_01(f);
return
end

function f = s_multi(y,A,B,C)

tmp1 = (4*A+2)*pi*(0.5-(abs(y-C)/(2*(floor(C-y)+C))));
tmp2 = 4*B*(abs(y-C)/(2*(floor(C-y)+C)))^2;

% the cos(tmp1)+tmp2
f = (1+cos(tmp1)+tmp2)/(B+2);
f = correct_to_01(f);
return
end 

%%%%% Reduction function
function f = r_sum(y,w)
f = y*w'/sum(w);        % Assuming both y, w both are row vectors
f = correct_to_01(f);
return

end 

function f = r_nonsep(y,A)

S = length(y);
assert(rem(S,A) == 0);

f = 0;

for j = 1:S
    tmp1 = 0;
    for k = 0:A-2
        tmp1 = tmp1+abs(y(j)-y(1+rem((j+k),S)));
    end
    f = f+y(j)+tmp1;
end

f = f / ((S/A)*ceil(A/2)*(1+2*A-2*ceil(A/2)));
f = correct_to_01(f);
return
end 

%%%% correct to 0-1
function b = correct_to_01(a)
eps = 1e-10;

min_eps = 0-eps;
max_eps = 1+eps;
if a<=0 && a>=min_eps
    b = 0;
elseif a>=1 && a <= max_eps
    b = 1;
else
   b = a;
end

return
end 
