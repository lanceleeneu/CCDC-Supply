%% ZDT6 benchmark function
function z=MyCost6(x)
        
        
        xv=x(:,2:10);
        gx=1+9*(sum(xv,2)/9).^0.25;

        z1=1-(exp(-4*x(:,1))).*(sin(6*pi*x(:,1))).^6;
        z2=gx.*(1-(z1./gx).^2);
        z=[z1;z2];
    
end      
  