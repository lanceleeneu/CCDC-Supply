%% ZDT3 benchmark function
function z=MyCost3(x)
              
        xv=x(:,2:30);
        gx=1+9*(sum(xv,2)/29);

        z1=x(:,1);
        z2=gx.*(1-sqrt(x(:,1)./gx)-(x(:,1)./gx).*sin(10*pi*x(:,1)));
        z=[z1;z2];
    
end      
  