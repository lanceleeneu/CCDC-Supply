%% DTLZ2 Test Suite
function z=MyCost41(x)

    [num,dim]=size(x);

    g=sum(x(num,5:dim).^2);

    z1=(1+g).*cos(0.5*pi*x(:,1)).*cos(0.5*pi*x(:,2)).*cos(0.5*pi*x(:,3)).*cos(0.5*pi*x(:,4));
    z2=(1+g).*cos(0.5*pi*x(:,1)).*cos(0.5*pi*x(:,2)).*cos(0.5*pi*x(:,3)).*sin(0.5*pi*x(:,4));
    z3=(1+g).*cos(0.5*pi*x(:,1)).*cos(0.5*pi*x(:,2)).*sin(0.5*pi*x(:,3));
    z4=(1+g).*cos(0.5*pi*x(:,1)).*sin(0.5*pi*x(:,2));
    z5=(1+g).*sin(0.5*pi*x(:,1));

    z=[z1;z2;z3;z4;z5];
end 