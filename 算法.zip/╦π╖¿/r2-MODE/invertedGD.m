function IGD=invertedGD(PFCosts,PFt)
    PF=PFCosts';
    
    [NP,nn]=size(PF);
    [NPt,nnt]=size(PFt);
    
    for i=1:NPt
        for j=1:NP
            ED(j)=norm(PFt(i,:)-PF(j,:));
        end 
        IGD(i)=min(ED);
    end 
    IGD=mean(IGD);
end 