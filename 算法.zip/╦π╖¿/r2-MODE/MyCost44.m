%% DTLZ2 Test Suite
function z=MyCost44(x)

    [num,dim]=size(x);

    g=sum(x(num,15:dim).^2);
    
    z1=(1+g).*cos(0.5*pi*x(:,1)).*cos(0.5*pi*x(:,2)).*cos(0.5*pi*x(:,3)).*cos(0.5*pi*x(:,4)).*cos(0.5*pi*x(:,5)).*cos(0.5*pi*x(:,6)).*cos(0.5*pi*x(:,7))...
        .*cos(0.5*pi*x(:,8)).*cos(0.5*pi*x(:,9)).*cos(0.5*pi*x(:,10)).*cos(0.5*pi*x(:,11)).*cos(0.5*pi*x(:,12)).*cos(0.5*pi*x(:,13)).*cos(0.5*pi*x(:,14));  
    
    z2=(1+g).*cos(0.5*pi*x(:,1)).*cos(0.5*pi*x(:,2)).*cos(0.5*pi*x(:,3)).*cos(0.5*pi*x(:,4)).*cos(0.5*pi*x(:,5)).*cos(0.5*pi*x(:,6)).*cos(0.5*pi*x(:,7))...
        .*cos(0.5*pi*x(:,8)).*cos(0.5*pi*x(:,9)).*cos(0.5*pi*x(:,10)).*cos(0.5*pi*x(:,11)).*cos(0.5*pi*x(:,12)).*cos(0.5*pi*x(:,13)).*sin(0.5*pi*x(:,14));     
    
    z3=(1+g).*cos(0.5*pi*x(:,1)).*cos(0.5*pi*x(:,2)).*cos(0.5*pi*x(:,3)).*cos(0.5*pi*x(:,4)).*cos(0.5*pi*x(:,5)).*cos(0.5*pi*x(:,6)).*cos(0.5*pi*x(:,7))...
        .*cos(0.5*pi*x(:,8)).*cos(0.5*pi*x(:,9)).*cos(0.5*pi*x(:,10)).*cos(0.5*pi*x(:,11)).*cos(0.5*pi*x(:,12)).*sin(0.5*pi*x(:,13));    
    
    z4=(1+g).*cos(0.5*pi*x(:,1)).*cos(0.5*pi*x(:,2)).*cos(0.5*pi*x(:,3)).*cos(0.5*pi*x(:,4)).*cos(0.5*pi*x(:,5)).*cos(0.5*pi*x(:,6)).*cos(0.5*pi*x(:,7))...
        .*cos(0.5*pi*x(:,8)).*cos(0.5*pi*x(:,9)).*cos(0.5*pi*x(:,10)).*cos(0.5*pi*x(:,11)).*sin(0.5*pi*x(:,12));    
    
    z5=(1+g).*cos(0.5*pi*x(:,1)).*cos(0.5*pi*x(:,2)).*cos(0.5*pi*x(:,3)).*cos(0.5*pi*x(:,4)).*cos(0.5*pi*x(:,5)).*cos(0.5*pi*x(:,6)).*cos(0.5*pi*x(:,7))...
        .*cos(0.5*pi*x(:,8)).*cos(0.5*pi*x(:,9)).*cos(0.5*pi*x(:,10)).*sin(0.5*pi*x(:,11));
    
    z6=(1+g).*cos(0.5*pi*x(:,1)).*cos(0.5*pi*x(:,2)).*cos(0.5*pi*x(:,3)).*cos(0.5*pi*x(:,4)).*cos(0.5*pi*x(:,5)).*cos(0.5*pi*x(:,6)).*cos(0.5*pi*x(:,7))...
        .*cos(0.5*pi*x(:,8)).*cos(0.5*pi*x(:,9)).*sin(0.5*pi*x(:,10));
    
    z7=(1+g).*cos(0.5*pi*x(:,1)).*cos(0.5*pi*x(:,2)).*cos(0.5*pi*x(:,3)).*cos(0.5*pi*x(:,4)).*cos(0.5*pi*x(:,5)).*cos(0.5*pi*x(:,6)).*cos(0.5*pi*x(:,7))...
    .*cos(0.5*pi*x(:,8)).*sin(0.5*pi*x(:,9));
    
    z8=(1+g).*cos(0.5*pi*x(:,1)).*cos(0.5*pi*x(:,2)).*cos(0.5*pi*x(:,3)).*cos(0.5*pi*x(:,4)).*cos(0.5*pi*x(:,5)).*cos(0.5*pi*x(:,6)).*cos(0.5*pi*x(:,7))...
    .*sin(0.5*pi*x(:,8));
    z9=(1+g).*cos(0.5*pi*x(:,1)).*cos(0.5*pi*x(:,2)).*cos(0.5*pi*x(:,3)).*cos(0.5*pi*x(:,4)).*cos(0.5*pi*x(:,5)).*cos(0.5*pi*x(:,6)).*sin(0.5*pi*x(:,7));

    z10=(1+g).*cos(0.5*pi*x(:,1)).*cos(0.5*pi*x(:,2)).*cos(0.5*pi*x(:,3)).*cos(0.5*pi*x(:,4)).*cos(0.5*pi*x(:,5)).*sin(0.5*pi*x(:,6));
    z11=(1+g).*cos(0.5*pi*x(:,1)).*cos(0.5*pi*x(:,2)).*cos(0.5*pi*x(:,3)).*cos(0.5*pi*x(:,4)).*sin(0.5*pi*x(:,5));
    z12=(1+g).*cos(0.5*pi*x(:,1)).*cos(0.5*pi*x(:,2)).*cos(0.5*pi*x(:,3)).*sin(0.5*pi*x(:,4));
    z13=(1+g).*cos(0.5*pi*x(:,1)).*cos(0.5*pi*x(:,2)).*sin(0.5*pi*x(:,3));
    z14=(1+g).*cos(0.5*pi*x(:,1)).*sin(0.5*pi*x(:,2));
    z15=(1+g).*sin(0.5*pi*x(:,1));

    z=[z1;z2;z3;z4;z5;z6;z7;z8;z9;z10;z11;z12;z13;z14;z15];
end 