%% DTLZ5 Test Suite
% test the convergence of algorithm when focus the curve.
function z=MyCost15(x)

    [num,dim]=size(x);

    g=sum((x(num,3:dim)-0.5).^2);   

    z1=(1+g).*cos(0.5*pi*x(:,1)).*cos(pi*(1+2.0*g.*x(:,2))./(4.0*(1+g)));
    z2=(1+g).*cos(0.5*pi*x(:,1)).*sin(pi*(1+2.0*g.*x(:,2))./(4.0*(1+g)));
    z3=(1+g).*sin(0.5*pi*x(:,1));

    z=[z1;z2;z3];
end 