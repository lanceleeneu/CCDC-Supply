%% DTLZ2 Test Suite
% Analyze the MOPs extended to the many-objective optimization and the
% convergence of the algorithms.

function z=MyCost12(x)

    [num,dim]=size(x);

    g=sum(x(num,3:dim).^2);

    z1=(1+g).*cos(0.5*pi*x(:,1)).*cos(0.5*pi*x(:,2));
    z2=(1+g).*cos(0.5*pi*x(:,1)).*sin(0.5*pi*x(:,2));
    z3=(1+g).*sin(0.5*pi*x(:,1));

    z=[z1;z2;z3];
end 