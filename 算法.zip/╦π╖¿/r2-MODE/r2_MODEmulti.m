clc;
clear;
tic;
format long;
format compact;

problems = {'43'};
problem_length = length(problems);
totalrun       = 30;

for i = 1 : problem_length
    problem = problems{i};
    fprintf('Running on %s...\n', problem);
    for j = 1 : totalrun
        [SP,GD,IGD,pareto]=r2_MODE(problem);
%         eval(['save pareto_' sprintf(problems{i}) '_' num2str(j) ' pareto']);
%         eval(['save GD_' sprintf(problems{i}) '_' num2str(j) ' GD']);
%         eval(['save IGD_' sprintf(problems{i}) '_' num2str(j) ' IGD']);
%         eval(['save HV_' sprintf(problems{i}) '_' num2str(j) ' HV']);
%         eval(['save SP_' sprintf(problems{i}) '_' num2str(j) ' SP']);
        eval(['save pareto_2_' num2str(j) ' pareto']);
        eval(['save GD_2_' num2str(j) ' GD']);
        eval(['save IGD_2_' num2str(j) ' IGD']);
        %eval(['save HV_' sprintf(problems{i}) '_' num2str(j) ' HV']);
        eval(['save SP_2_' num2str(j) ' SP']);
    end
end

toc;