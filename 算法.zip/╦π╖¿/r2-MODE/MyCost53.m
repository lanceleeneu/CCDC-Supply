%% DTLZ1 Test Suite
% Analyze the Multifrontal multiobjective optimization problems, the
% problem has 11^k-1 local Pareto front and linear hyperplane in the test.

function z=MyCost53(x)

    [num,dim]=size(x);

    g=100*(dim-2)+100*sum((x(num,3:dim)-repmat(0.5,[num dim-2])).^2-cos(20*pi*(x(num,3:dim)-repmat(0.5,[num dim-2]))));

    z1=0.5*(1+g)*x(:,1).*x(:,2).*x(:,3).*x(:,4).*x(:,5).*x(:,6).*x(:,7).*x(:,8).*x(:,9);
    z2=0.5*(1+g)*x(:,1).*x(:,2).*x(:,3).*x(:,4).*x(:,5).*x(:,6).*x(:,7).*x(:,8).*(1-x(:,9));
    z3=0.5*(1+g)*x(:,1).*x(:,2).*x(:,3).*x(:,4).*x(:,5).*x(:,6).*x(:,7).*(1-x(:,8));
    z4=0.5*(1+g)*x(:,1).*x(:,2).*x(:,3).*x(:,4).*x(:,5).*x(:,6).*(1-x(:,7));
    z5=0.5*(1+g)*x(:,1).*x(:,2).*x(:,3).*x(:,4).*x(:,5).*(1-x(:,6));
    z6=0.5*(1+g)*x(:,1).*x(:,2).*x(:,3).*x(:,4).*(1-x(:,5));
    z7=0.5*(1+g)*x(:,1).*x(:,2).*x(:,3).*(1-x(:,4));
    z8=0.5*(1+g)*x(:,1).*x(:,2).*(1-x(:,3));
    z9=0.5*(1+g)*x(:,1).*(1-x(:,2));
    z10=0.5*(1+g)*(1-x(:,1));
    z=[z1;z2;z3;z4;z5;z6;z7;z8;z9;z10];
end 