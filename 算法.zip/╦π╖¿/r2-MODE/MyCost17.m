%% DTLZ7 test suite
function z=MyCost17(x)
    [num,dim]=size(x);
    
    g=1+(9/20)*sum(x(num,3:dim));
    
    h=3-sum((x(num,1:2).*(1+sin(3*pi*x(num,1:2))))/(1+g));
    
    z1=x(:,1);
    z2=x(:,2);
    z3=(1+g).*h;

    z=[z1;z2;z3];
    
end 