%% UF1 benchmark function
function z=MyCost21(x)
        
    [num, dim]  = size(x);
    tmp         = zeros(num,dim);

    tmp(:,2:dim)= (x(:,2:dim) - sin(6.0*pi*repmat(x(:,1),[1,dim-1]) + pi/dim*repmat((2:dim),[num,1]))).^2;
    tmp1        = sum(tmp(:,3:2:dim));  % odd index
    tmp2        = sum(tmp(:,2:2:dim));  % even index
    z1      = x(:,1)             + 2.0*tmp1/size(3:2:dim,2);
    z2      = 1.0 - sqrt(x(:,1)) + 2.0*tmp2/size(2:2:dim,2);
    
     z=[z1;z2];
    
end      
  