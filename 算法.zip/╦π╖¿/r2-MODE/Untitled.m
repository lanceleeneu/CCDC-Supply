clear all
clc
ZDT=[];
for i=1:30
     load(['IGD_WFG9_', num2str(i)])
     ZDT=[ZDT,IGD];
end
mean=mean(ZDT);
std=std(ZDT);