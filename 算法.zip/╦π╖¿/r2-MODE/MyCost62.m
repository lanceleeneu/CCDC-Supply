%% DTLZ3 Test Suite
% The modification of DTLZ2 and the g function is as the same as the DTLZ1
% 3^K -1 local Pareto front in this test.

function z=MyCost62(x)

    [num,dim]=size(x);

    g=100*(dim-2)+100*sum((x(num,3:dim)-repmat(0.5,[num dim-2])).^2-cos(20*pi*(x(num,3:dim)-repmat(0.5,[num dim-2]))));

    z1=(1+g).*cos(0.5*pi*x(:,1)).*cos(0.5*pi*x(:,2)).*cos(0.5*pi*x(:,3)).*cos(0.5*pi*x(:,4)).*cos(0.5*pi*x(:,5)).*cos(0.5*pi*x(:,6)).*cos(0.5*pi*x(:,7));
    z2=(1+g).*cos(0.5*pi*x(:,1)).*cos(0.5*pi*x(:,2)).*cos(0.5*pi*x(:,3)).*cos(0.5*pi*x(:,4)).*cos(0.5*pi*x(:,5)).*cos(0.5*pi*x(:,6)).*sin(0.5*pi*x(:,7));
    z3=(1+g).*cos(0.5*pi*x(:,1)).*cos(0.5*pi*x(:,2)).*cos(0.5*pi*x(:,3)).*cos(0.5*pi*x(:,4)).*cos(0.5*pi*x(:,5)).*sin(0.5*pi*x(:,6));
    z4=(1+g).*cos(0.5*pi*x(:,1)).*cos(0.5*pi*x(:,2)).*cos(0.5*pi*x(:,3)).*cos(0.5*pi*x(:,4)).*sin(0.5*pi*x(:,5));
    z5=(1+g).*cos(0.5*pi*x(:,1)).*cos(0.5*pi*x(:,2)).*cos(0.5*pi*x(:,3)).*sin(0.5*pi*x(:,4));
    z6=(1+g).*cos(0.5*pi*x(:,1)).*cos(0.5*pi*x(:,2)).*sin(0.5*pi*x(:,3));
    z7=(1+g).*cos(0.5*pi*x(:,1)).*sin(0.5*pi*x(:,2));
    z8=(1+g).*sin(0.5*pi*x(:,1));

    z=[z1;z2;z3;z4;z5;z6;z7;z8];
end 