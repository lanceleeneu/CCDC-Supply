%% UF3 benchmark function
function z=MyCost23(x)

    [num, dim]   = size(x);
    Y            = zeros(num,dim);
    Y(:,2:dim)   = x(:,2:dim) - repmat(x(:,1),[1,dim-1]).^(0.5+1.5*(repmat((2:dim),[num,1])-2.0)/(dim-2.0));
    tmp1         = zeros(num,dim);
    tmp1(:,2:dim)= Y(:,2:dim).^2;
    tmp2         = zeros(num,dim);
    tmp2(:,2:dim)= cos(20.0*pi*Y(:,2:dim)./sqrt(repmat((2:dim),[num,1])));
    tmp11        = 4.0*sum(tmp1(:,3:2:dim)) - 2.0*prod(tmp2(:,3:2:dim)) + 2.0;  % odd index
    tmp21        = 4.0*sum(tmp1(:,2:2:dim)) - 2.0*prod(tmp2(:,2:2:dim)) + 2.0;  % even index
    z1       = x(:,1)             + 2.0*tmp11/size(3:2:dim,2);
    z2       = 1.0 - sqrt(x(:,1)) + 2.0*tmp21/size(2:2:dim,2);
     
     z=[z1;z2];
    
end      
  