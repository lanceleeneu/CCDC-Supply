%% UF9 benchmark function
function z=MyCost29(x)
    E           = 0.1;
    [num, dim]  = size(x);
    Y           = zeros(num,dim);
    Y(:,3:dim)  = (x(:,3:dim) - 2.0*repmat(x(:,2),[1,dim-2]).*sin(2.0*pi*repmat(x(:,1),[1,dim-2]) + pi/dim*repmat((3:dim),[num,1]))).^2;
    tmp1        = sum(Y(:,4:3:dim));  % j-1 = 3*k
    tmp2        = sum(Y(:,5:3:dim));  % j-2 = 3*k
    tmp3        = sum(Y(:,3:3:dim));  % j-0 = 3*k
    tmp         = max(0,(1.0+E)*(1-4.0*(2.0*x(:,1)-1).^2));
    z1      = 0.5*(tmp+2*x(:,1)).*x(:,2)     + 2.0*tmp1/size(4:3:dim,2);
    z2      = 0.5*(tmp-2*x(:,2)+2.0).*x(:,2) + 2.0*tmp2/size(5:3:dim,2);
    z3      = 1-x(:,2)                       + 2.0*tmp3/size(3:3:dim,2);

   
     z=[z1;z2;z3];
    
end      
  