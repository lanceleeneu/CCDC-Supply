function gama=converge(PFCosts,PFt)
 
PF=PFCosts';

[NP,nn]=size(PF);
[NPt,nnt]=size(PFt);

for i=1:NP
    for j=1:NPt
        ED(j)=norm(PF(i,:)-PFt(j,:));
    end
    gama(i)=min(ED);   
end

gama=mean(gama);



